# Sonu Dev — Internship Task 2

## Advanced CSS3 & Responsive Architecture

This package upgrades the semantic portfolio from Task 1 with:

- CSS Grid for two-dimensional layouts
- Flexbox for component alignment
- Mobile-first responsive design
- Responsive breakpoints for mobile, tablet and desktop
- CSS custom properties / variables
- Light and dark theme
- CSS gradients
- Backdrop blur
- Hover transitions
- Keyframe animations
- Responsive typography using `clamp()`
- Accessibility focus styles
- Reduced-motion support

## Files

- `style.css` — replace your current stylesheet with this file.
- `script.js` — add/replace your JavaScript with this theme-toggle script.
- `navbar-theme-button.html` — copy the button into your existing navbar.
- `README.md` — implementation notes.

## How to use

1. Open your existing Task 1 project.
2. Replace the old CSS with `style.css`.
3. Add the theme button from `navbar-theme-button.html` inside the navbar.
4. Add the JavaScript from `script.js`.
5. Open the website and test it at mobile, tablet and desktop widths.
6. Commit and push the changes to GitHub Pages.

## Important

The CSS uses semantic class names such as `.hero`, `.services-grid`, `.projects-grid`, `.service-card`, `.project-card`, `.contact-card`, etc.

If your Task 1 HTML uses different class names, rename the selectors in `style.css` to match your existing HTML rather than rebuilding the HTML.
