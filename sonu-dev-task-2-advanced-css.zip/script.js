const themeToggle = document.querySelector(".theme-toggle");

const savedTheme = localStorage.getItem("theme");

if (savedTheme) {
    document.documentElement.dataset.theme = savedTheme;
}

function updateThemeIcon() {
    if (!themeToggle) return;

    const isDark =
        document.documentElement.dataset.theme === "dark";

    themeToggle.textContent = isDark ? "☀" : "☾";
}

themeToggle?.addEventListener("click", () => {
    const currentTheme =
        document.documentElement.dataset.theme;

    const newTheme =
        currentTheme === "dark"
            ? "light"
            : "dark";

    document.documentElement.dataset.theme =
        newTheme;

    localStorage.setItem("theme", newTheme);

    updateThemeIcon();
});

updateThemeIcon();
